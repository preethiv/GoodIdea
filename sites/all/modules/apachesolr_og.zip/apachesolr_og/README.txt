
README for Apache Solr Organic Groups Integration

This module depends on Apache Solr Search Integration and adds additional 
information to the search index to enable group faceting, per group 
searching, etc.

This module is packaged with Apache Solr Search Integration 6.x-1.x, 
but is split out as a separate project for 6.x-2.x and 7.x-1.x to enable
it to develop a richer and more complete set of features.

